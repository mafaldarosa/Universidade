/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package so2;

public interface BD_commands_interface extends java.rmi.Remote {

    public void adciona_produto(Produto novo_produto) throws java.rmi.RemoteException;

    public void adiciona_necessidade(Necessidade nova_necessidade, int id) throws java.rmi.RemoteException;

    public String consultar_n() throws java.rmi.RemoteException;

    public void create_t() throws java.rmi.RemoteException;
    
    public void delete_necessidade(int id, String tipo_produto) throws java.rmi.RemoteException;

}
