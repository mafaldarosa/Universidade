/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package so2;

import java.io.Serializable;



public class Necessidade implements Serializable
{
    String tipo_produto;
    int cod_user;
    int id;
    
    
    public String get_tipo()
    {
        return this.tipo_produto;
    }
    
    public int get_coduser()
    {
        return this.cod_user;
    }
    
    public void set_tipo(String tipo)
    {
        this.tipo_produto = tipo;
    }
    
    public void set_id(int id)
    {
        this.id = id;
    }
    
    public void set_coduser(int cod_user)
    {
       this.cod_user = cod_user;
    }
}
