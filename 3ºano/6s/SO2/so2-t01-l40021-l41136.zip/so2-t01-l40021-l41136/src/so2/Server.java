/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package so2;

public class Server 
{
      
   
    public static void main(String args[]) throws Exception {

        int regPort = 9000; 
        
        System.out.println("À espera de conexão...");
        
        if (args.length < 1) {
            System.out.println("<registryPort>");
            System.exit(1);
        }

        try {
            regPort = Integer.parseInt(args[0]);

            System.out.println(java.net.InetAddress.getLocalHost());

            // Criar um objeto remoto.
            BD_commands_impl obj = new BD_commands_impl("localhost", "trab1", "teste", "teste");

            java.rmi.registry.LocateRegistry.createRegistry(regPort);

            java.rmi.registry.Registry registry = java.rmi.registry.LocateRegistry.getRegistry(regPort);

            obj.create_t();
            
            // Faz o registo do par (nome, referencia para objeto remoto)
            registry.rebind("produto", obj);

            System.out.println("Bound RMI object in registry");
            System.out.println("servidor online");

            
        } catch (Exception ex) {
	    ex.printStackTrace();
	}
    }
       
}
