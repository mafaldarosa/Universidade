/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package so2;

import java.sql.*;

// Baseado no Connector do professor
public class Postgres_connector {
    
    private String PG_HOST;
    private String PG_DB;
    private String USER;
    private String PWD;
    
    Connection con = null;
    Statement stmt = null;
    
//-------------------------------------------------------------------------------------------------------------
    public Postgres_connector(String host, String db, String user, String pw) {
        
        PG_HOST = host;
        PG_DB = db;
        USER = user;
        PWD = pw;
    }

//-------------------------------------------------------------------------------------------------------------    
    public void connect() throws Exception {
        try {
            Class.forName("org.postgresql.Driver");
            
            // URL
            con = DriverManager.getConnection("jdbc:postgresql://" + PG_HOST + ":5432/" + PG_DB, USER, PWD);
            
            stmt = con.createStatement();
            
            if (stmt != null) {
                System.out.println("You are connected!");
            } else {
                System.out.println("ERROR: Something went wrong!");
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Problems occured while setting the connection!");
        }
    }
    
//-------------------------------------------------------------------------------------------------------------    
    public void disconnect() throws SQLException {

        if (stmt != null && con != null) {
            stmt.close();
            con.close();
        }
    }
}