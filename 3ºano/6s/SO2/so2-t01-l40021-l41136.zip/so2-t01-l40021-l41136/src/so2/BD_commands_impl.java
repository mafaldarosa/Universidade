/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package so2;

import java.rmi.RemoteException;
import java.sql.*;
import java.rmi.server.UnicastRemoteObject;

public class BD_commands_impl extends UnicastRemoteObject implements BD_commands_interface, java.io.Serializable {

    ResultSet result;
    Postgres_connector db;

    public BD_commands_impl(String host, String db, String user, String pw) throws java.rmi.RemoteException {
        super();
        this.db = new Postgres_connector(host, db, user, pw);
    }

    @Override
    public void adciona_produto(Produto novo_produto) throws java.rmi.RemoteException {

        try {
            db.connect();

            String tipo_produto = novo_produto.get_tipo();
            String local_produto = novo_produto.get_local();

            result = db.stmt.executeQuery("SELECT tipo_produto FROM produto WHERE tipo_produto = '" + tipo_produto + "';");
            if(result.next())
            {
               System.out.println("O produto já existe!");  
            }
            else
            {
               db.stmt.executeUpdate("INSERT INTO produto VALUES('" + tipo_produto + "','" + local_produto + "');");
               System.out.print("O produto foi registado!");
            }
            result.close();
            
            db.disconnect();
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Problema ao inserir o produto!");
        }

    }

    @Override
    public void adiciona_necessidade(Necessidade nova_necessidade, int id) throws java.rmi.RemoteException {
        try {
            db.connect();

            String tipo_produto = nova_necessidade.get_tipo();
            int cod_user = nova_necessidade.get_coduser();

            result = db.stmt.executeQuery("SELECT tipo_produto FROM necessidades WHERE tipo_produto = '" + tipo_produto + "' AND codigo_utilizador = '" + cod_user + "';");
            if(result.next())
            {
               System.out.println("Já existe uma necessidade com este código!");  
            }
            else
            {
               db.stmt.executeUpdate("INSERT INTO necessidades VALUES('" + tipo_produto + "','" + cod_user + "')");
               System.out.print("A necessidade foi registada!");
            }
            result.close();
            

            db.disconnect();

        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Problema ao inserir necessidade!");
        }
    }

    @Override
    public String consultar_n() throws java.rmi.RemoteException {
        String s = "";

        try {
            db.connect();

            int cod_user = 0;
            String tipo_produto = "";

            result = db.stmt.executeQuery("SELECT tipo_produto, codigo_utilizador FROM necessidades ORDER BY codigo_utilizador");

            while (result.next()) {
                cod_user = result.getInt("codigo_utilizador");
                tipo_produto = result.getString("tipo_produto");

                s = s + cod_user + "->" + tipo_produto + "\n";
            }
            result.close();

            db.disconnect();

        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Problemas ao obter a lista das necessidades da Base de Dados!");
        }
        if (s.equals("")) {
            return "Não há dados suficientes";
        }
        return s;

    }

    @Override
    public void create_t() throws java.rmi.RemoteException {
        try {
            db.connect();

            db.stmt.executeUpdate("CREATE TABLE IF NOT EXISTS produto(\n"
                    + "tipo_produto varchar(50),\n"
                    + "local_produto varchar(50),\n"
                    + "PRIMARY KEY(tipo_produto)\n"
                    + ");");

            db.stmt.executeUpdate("CREATE TABLE IF NOT EXISTS necessidades(\n"
                    + "tipo_produto varchar(50),\n"
                    + "codigo_utilizador varchar(10)\n"
                    + ");");
            
            
            
            db.disconnect();

        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Problemas ao obter a lista das necessidades da Base de Dados!");
        }
    }

    @Override
    public void delete_necessidade(int id, String tipo_produto) throws RemoteException 
    {
        try {
            db.connect();
            
            db.stmt.executeUpdate("DELETE FROM necessidades WHERE codigo_utilizador = '" + id + "' AND tipo_produto = '" + tipo_produto + "';");
                      

            db.disconnect();

        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Problema ao eliminar necessidade!");
        }
        
        
        
    }
}
