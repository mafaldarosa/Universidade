/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package so2;

import java.rmi.RemoteException;
import java.util.Random;
import java.util.Scanner;

public class User 
{
   
    
    private static void Menu(BD_commands_interface obj) throws RemoteException
    {
        Scanner scan = new Scanner(System.in);
        
        System.out.println("Seja Bem-Vindo!");
       
        
                      
        while (true)
        {
            comandos();
            
            String caracter = scan.nextLine();
                        
            switch (caracter) {
                case "1":
                    //consultar
                    consulta_necessidade(obj);
                    break;
                case "2":
                    //Registar produto
                    disponibilizar(obj);
                    break;
                case "3":
                    //Registar necessidade
                    registo_n(obj);
                    break;
                case "4":
                    //apagar
                    apagar_n(obj);
                    break;
                case "Sair":
                    sair_programa();
                    break;
                default:
                    System.out.println("Comando não reconhecido!");
                    break;
            }
        }
    }
    
    private static void comandos()
    {
        System.out.println("Lista de comandos a utilizar: ");
        System.out.println("1 -> Consultar necessidades");
        System.out.println("2 -> Registar produto");
        System.out.println("3 -> Registar necessidade");
        System.out.println("4 -> Apagar as necessidades");
        System.out.println("Sair -> Sair do programa");
    }
    
    private static void sair_programa()
    {
        System.out.println("Logout com sucesso!");
        System.exit(0);
    }
   
    private static void disponibilizar(BD_commands_interface obj) throws RemoteException
    {
        Produto novo_produto = new Produto();
        
        System.out.println("Indique o tipo de produto: ");
        Scanner sc = new Scanner (System.in);
        String tp = "";
        String lp = "";
        
        tp = sc.nextLine();
      
        novo_produto.set_tipo(tp);
        
        System.out.println("Indique o local do produto: ");
        
        lp = sc.nextLine();
        
        novo_produto.set_local(lp);
        
        obj.adciona_produto(novo_produto);
    }
    
    private static void consulta_necessidade(BD_commands_interface obj) throws RemoteException
    {
        
            System.out.println("Lista das necessidades: \n");
            String lista = obj.consultar_n();
            System.out.println(lista);

        
    }
    private static void registo_n(BD_commands_interface obj) throws RemoteException
    {
        Scanner scan = new Scanner(System.in);
        
        System.out.println("Indique o tipo de produto: ");
        String tp = scan.nextLine();
        
        System.out.println("Indique-nos o seu ID: ");
       
        int id = scan.nextInt();      
        
        Necessidade nova_necessidade = new Necessidade();
       
        nova_necessidade.set_id(id);
       
        nova_necessidade.set_tipo(tp);
        
        int first, second,third, fourth;
        
        Random rand = new Random();
        
        first = rand.nextInt(10);
        second = rand.nextInt(10);
        third = rand.nextInt(10);
        fourth = rand.nextInt(10);
        
        int cod_u = (first * second * third * fourth) + id;
        
        nova_necessidade.set_coduser(cod_u);
     
        obj.adiciona_necessidade(nova_necessidade,cod_u);
        
    }
    
    private static void apagar_n(BD_commands_interface obj) throws RemoteException
    {
        Scanner scan = new Scanner(System.in);
        
        String consulta= obj.consultar_n();
        System.out.println(consulta);
        System.out.println("Indique o tipo do produto: ");
        String necessidade_tp = scan.nextLine();
        
        System.out.println("Indique o id da necessidade: ");
        int necessiadade_id = scan.nextInt();
        
        obj.delete_necessidade(necessiadade_id, necessidade_tp);
        
    }
    
    
    public static void main(String args[]) {
      
       
        if (args.length != 2) 
        { // requer 2 argumentos
            System.out.println("Argumentos: <registryHost> <registryPort>");
            System.exit(1);
        }
        
        String regHost = args[0]; // host
        String regPort = args[1]; // porto do binder

        try {
            // Para obter uma referencia para o objeto remoto a partir do nome(neste caso "produto")
            // rmi//hostname:port/objectName
            BD_commands_interface obj = (BD_commands_interface) java.rmi.Naming.lookup("rmi://" + regHost + ":" + regPort + "/produto");
            
            Menu(obj);

        } catch (Exception ex) {
	    ex.printStackTrace();
	}
    }
    
}
