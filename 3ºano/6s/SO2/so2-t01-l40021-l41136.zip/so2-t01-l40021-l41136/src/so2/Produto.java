/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package so2;

import java.io.Serializable;
import java.util.Scanner;

public class Produto implements Serializable
{
    String tipo_produto;
    String local_produto;
    
    public String get_tipo()
    {
        return this.tipo_produto;
    }
    
    public String get_local()
    {
        return this.local_produto;
    }
    
    public void set_tipo(String tipo)
    {
       this.tipo_produto = tipo;
    }
    
    public void set_local(String local)
    {
        this.local_produto = local;
    }
}
