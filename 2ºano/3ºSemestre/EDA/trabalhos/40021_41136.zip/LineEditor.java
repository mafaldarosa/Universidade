import java.util.Scanner;

class LineEditor {

    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        DoubleLinkedList linhas = new DoubleLinkedList();
        String caracter;
        String comando,linha;

        do {
            System.out.print("Comando ->> ");
            comando = scanner.next();
            switch(comando){

                case "inserir" :
                    do {
                        linha = scanner.next();
                        if(linha.length()==1 && linha.charAt(0)=='.')
                            break;
                        linhas.Adicionar(linha);
                    }
                    while(true);
                    break;

                case "eliminar" :
                        linhas.Eliminar();

                    break;

                case "baixar" :
                    if(linhas.Vazia()||linhas.Fim())
                        System.out.println("erro");
                    else {
                        linhas.Seguinte();
                        System.out.println(linhas.Atual());
                        System.out.print(linhas);
                    }
                    break;

                case "subir" :
                        linhas.Anterior();
                        System.out.println(linhas.Atual());
                        System.out.print(linhas);
                    break;

                case "linhaAtual":

                        System.out.println(linhas.Atual());
                    break;

                case "print":
                    System.out.print(linhas);
                    break;

                case "sair": break;

                default:
                    System.out.println("Erro");

            }
        }
        while(comando!="sair");
    }
}
