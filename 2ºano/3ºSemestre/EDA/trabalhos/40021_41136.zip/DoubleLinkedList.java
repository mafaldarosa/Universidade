class DoubleLinkedList
{
    private Lista lista;

    private static class Lista{
        Lista anterior,seguinte;
        Object conteudo;

        Lista(Lista a,Object c,Lista s){
            anterior=a;
            conteudo=c;
            seguinte=s;
        }
    }

    public DoubleLinkedList(){
        lista=null;
    }

    public boolean Vazia(){
        return lista==null;
    }

    public boolean Fim(){
        return lista.seguinte==null;
    }

    public boolean Principio() {
        return lista.anterior==null;
    }

    public void Adicionar(Object c){

        if(lista==null) {
            lista = new Lista(null,c,null);
        }
        else if(lista.seguinte==null){
            lista.seguinte = new Lista(lista,c,null);
            lista = lista.seguinte;
        }
        else{
            lista.seguinte.anterior = new Lista(lista,c,lista.seguinte);
            lista.seguinte = lista.seguinte.anterior;
            lista=lista.anterior;
        }
    }

    public void Eliminar(){
        if(lista.seguinte==null){
            lista = lista.anterior;
            if(lista!=null)
                lista.seguinte=null;
        }
        else{
            lista.seguinte.anterior = lista.anterior;
            if(lista.anterior!=null)
                lista.anterior.seguinte = lista.seguinte;
            lista=lista.seguinte;
        }
    }

    public void Seguinte() {
        lista = lista.seguinte;
    }

    public void Anterior() {
        lista = lista.anterior;
    }

    public Object Atual() {
        return lista.conteudo;
    }

    public String toString(){
        Lista s;
        String str="";
        if(lista!=null){
            for(s=lista;s.anterior!=null; s=s.anterior);
            for(;s!=null;s=s.seguinte){
                if(s==lista)
                    str+="> ";
                else
                    str+="  ";
                str+=s.conteudo+"\n";
            }
        }
        return str;
    }
}