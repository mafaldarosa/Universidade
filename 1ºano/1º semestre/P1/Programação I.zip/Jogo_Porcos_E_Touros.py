import random

def gerador():
    n1 = str(round(random.random() * 9))
    n2 = str(round(random.random() * 9))
    n3 = str(round(random.random() * 9))
    n4 = str(round(random.random() * 9))
    if n2 == n1:
        n2 = str(round(random.random()) * 9)
    if n3 == n1 or n3 == n2:
        n3 = str(round(random.random()) * 9)
    if n4 == n1 or n4 == n2 or n4 == n3:
        n4 = str(round(random.random()) * 9)
    numran = n1 + n2 + n3 + n4
    return numran

numran = gerador()

def jogo(numran, n, c, tentativas):
    if len(n) == 4 and n[0] != n[1] and n[0] != n[2] and n[0] != n[3] and n[1] != n[2] and n[1] != n[3] and n[2] != n[3]:
        porcos = 0
        touros = 0
        for i in range(4):
            for j in range(4):
                if numran[i] == n[j]:
                    if i == j:
                        touros += 1
                    else:
                        porcos += 1
        if touros == 4:
            tentativas.append('T' + str(c) + ': ' + str(n) + ' ' + str(touros) + 'T ' + str(porcos) + 'P')
            return ("Acertou!!!")
        else:
            if porcos == 0 and touros == 0:
                return (str(touros) + 'T ' + str(porcos) + ' P')
            print(str(touros) + 'T ' + str(porcos) + ' P')
            tentativas.append('T' + str(c) + ': ' + str(n) + ' ' + str(touros) + 'T ' + str(porcos) + 'P')
    else:
        return 'O codigo tem de ter 4 digitos'

tentativas = []
n = ""
c = 0
while n != numran:
    c = c + 1
    n = str(input('Introduza o codigo de 4 digitos:'))
    print(jogo(numran, n, c,tentativas))
print("As suas tentativas foram:")
for i in range(len(tentativas)):
    print(tentativas[i])
