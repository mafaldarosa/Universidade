/* Mafalda Rosa 40021
    Maria Correia 39836
 */


import java.util.*;
import java.awt.Color;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import java.awt.event.*;

public class Tabuleiro {
    Random r;
    int tamanho;
    int tab[][];
    int cores;
    int gerador;
    int x;
    int y;
    int [][]coords;
    int [] coordenadas;
    int [] colunas;
    JFrame jframe = new JFrame ();
    JButton botao = new JButton ();



    Tabuleiro (int tamanho, int cores){
        this.tamanho= tamanho;
        this.tab = new int [tamanho][tamanho];
        this.cores= cores;
        r = new Random(gerador);
        this.criarTabuleiro();
        coordenadas = new int[tamanho*tamanho];
        colunas= new int [tamanho];

    }

    public Color Graphics(int numeros,JButton botao){
        if (numeros == 1){
            return Color.red;
        }else if (numeros == 2){
            return Color.green;
        }else if (numeros == 3){
            return Color.yellow;
        }else if (numeros == 4){
            return Color.blue;
        }else if (numeros == 5){
            return Color.pink;
        }else if (numeros == 6){
            return Color.orange;
        }else if (numeros == 7){
            return Color.magenta;
        }else if (numeros == 8){
            return Color.gray;
        }
        return Color.black;
    }


    void criarTabuleiro(){
        JFrame jframe = new JFrame ();
        jframe.setTitle("Fusion");
        jframe.setLayout(new GridLayout(tamanho,tamanho,5,5));
        jframe.setVisible(true);
        jframe.setSize(500, 500);

        for (int i=0; i<tamanho; i++) {
            for (int j = 0; j < tamanho; j++) {
                int cor = r.nextInt(cores);
                tab[i][j] = cor;
                botao = new JButton(String.valueOf(cor));
                Graphics(cor, botao);
                jframe.add(botao);
                botao.addActionListener(new ActionListener() {
                                            public void actionPerformed(ActionEvent a) {
                                                JButton clicar = (JButton) a.getSource();
                                                clicar.setVisible(false);
                                                for (int i = 0; i < tamanho; i++) {
                                                    for (int j = 0; j < tamanho; j++) {
                                                        if (clicar == botao) {
                                                            tab[i][j] = 0;
                                                            System.out.print(tab[i][j]);
                                                            System.out.print(tab);
                                                        }
                                                    }
                                                    System.out.println();
                                                }
                                                verifica_vizinhos(x, y, coords);
                                            }
                                        }
                );

            }

        }

                }

    void printTabuleiro(){
        String s = new String();
        for (int i=0;i<tab.length;i++){
            for (int j=0;j<tab[0].length;j++){
                s=s+ tab [i][j]+ " ";
            }
            s=s+"\n";
        }
        System.out.println(s);
    }

    public int[][] verifica_vizinhos(int x,int y, int [][] coords){

        try{

            if(tab[y][x-1]==tab[y][x] && !verifica(x-1,y,coords)&& tab[y][x-1]!=0){
                if (tab[y][x+1]==tab[x][y] && !verifica(x+1,y,coords) && tab[y][x+1]!=0)
                    coords = insereCoord(x,y,coords);
                coords = verifica_vizinhos(x-1,y,coords);
                coords = verifica_vizinhos(x+1,y,coords);
            }
            else if (tab[y][x-2]==tab[x][y] && !verifica(x-2,y,coords) && tab[y][x-2]!=0) {
                coords = insereCoord(x,y,coords);
                coords = verifica_vizinhos(x-1,y,coords);
                coords = verifica_vizinhos(x-2,y,coords);
            }
            else if (tab[y][x+1]==tab[y][x] && !verifica(x+1,y,coords)&& tab[y][x+1]!=0) {
                if (tab[y][x+2]==tab[y][x] && !verifica(x+2,y,coords)&& tab[y][x+2]!=0) {
                    coords = insereCoord(x,y,coords);
                    coords = verifica_vizinhos(x+1,y,coords);
                    coords = verifica_vizinhos(x+2,y,coords);
                }
            }

        }
        catch(IndexOutOfBoundsException e){

        }

        try{
            if(tab[y-1][x]==tab[y][x] && !verifica(x,y-1,coords)&& tab[y-1][x]!=0){
                if (tab[y+1][x]==tab[y][x] && !verifica(x,y+1,coords)&& tab[y+1][x]!=0) {
                    coords = insereCoord(x,y,coords);
                    coords = verifica_vizinhos(x,y-1,coords);
                    coords = verifica_vizinhos(x,y+1,coords);
                }
                else if (tab[y-2][x]==tab[x][y] && !verifica(x,y-2,coords) && tab[y-2][x]!=0) {
                    coords = insereCoord(x,y,coords);
                    coords = verifica_vizinhos(x,y-1,coords);
                    coords = verifica_vizinhos(x,y-2,coords);
                }
                else if (tab[y+1][x]==tab[y][x] && !verifica(x,y+1,coords)&& tab[y+1][x]!=0) {
                    if (tab[y+2][x]==tab[y][x] && !verifica(x,y+2,coords)&& tab[y+2][x]!=0) {
                        coords = insereCoord(x,y,coords);
                        coords = verifica_vizinhos(x,y+1,coords);
                        coords = verifica_vizinhos(x,y+2,coords);
                    }
                }
            }
        }
        catch(IndexOutOfBoundsException e){
        }

        if (!verifica(x,y,coords)){
            insereCoord(x,y,coords);
        }

        return coords;
    }






    public boolean verifica(int x, int y, int [][] coords){
        boolean result = false;
        for (int i =0; i<coords.length; i++){
            if (coords[i][0]==x && coords[i][1]==y){
                result = true;
            }
        }
        return result;
    }



    public int [][] insereCoord (int x, int y, int [][] coords){
        for (int i=0; i<coords.length; i++){
            if (coords[i][0]==33){
                coords[i][0]=x;
                coords[i][1]=y;
                break;
            }
        }
        return coords;
    }


    public boolean verifica_pos(int x, int y, int [][] coords){
        coords= this.verifica_vizinhos(x, y, coords);
        if(y<0 || x<0 || y>tamanho-1 || x>tamanho-1 || coords[1][0]==33 || tab[y][x]==0){
            return false;
        }
        return true;
    }


    public boolean verificaColunas(){
        for (int x=0; x<tab.length; x++){
            boolean var1 = true;
            for(int y=0; y<tab.length; y++){
                if (tab[y][x]==0 && y==tab.length-1){
                    for (int i=0;i<colunas.length;i++){
                        if (colunas[i]==x){
                            var1=false;
                        }
                    }
                    if (var1){
                        return true;
                    }
                }else if(tab[y][x]!=0){
                    break;
                }
            }
        }
        return false;
    }



    void arrumaTabuleiro(int change){
        int var=0;
        if (change==0){
            for (int y=0; y <tab.length; y++){
                for(int repeat=0; repeat<tab.length; repeat++){
                    for (int x=tab.length-1; x>0; x--){
                        if(tab[y][x]==0 && tab[y][x-1]!=0){
                            var=tab[y][x];
                            tab[y][x]=tab[y][x-1];
                            tab[y][x-1]=var;
                        }
                    }
                }
            }
        }else{
            for (int x=0; x <tab.length; x++){
                for(int repeat=0; repeat<tab.length; repeat++){
                    for (int y=tab.length-1; y>0; y--){
                        if(tab[y][x]==0 && tab[y-1][x]!=0){
                            var=tab[y][x];
                            tab[y][x]=tab[y-1][x];
                            tab[y-1][x]=var;
                        }
                    }
                }
            }
        }
    }



    public void jogadas(int[][] coords) {
        for (int i=0; i<coords.length;i++){
            if (coords[i][0]!=33){
                tab[coords[i][1]][coords[i][0]]=0;
            }
        }
        this.arrumaTabuleiro(1);
        if (this.verificaColunas()){
            this.arrumaTabuleiro(0);
        }
    }


    public boolean fim_de_jogo (){

        for (int x=0; x<tamanho; x++){
            for (int y=0; y<tamanho; y++){
                int coords[][]=new int [tamanho*tamanho][2];
                for( int i=0; i<coords.length; i++ ){
                    coords[i][0]=33;
                }
                coords= this.verifica_vizinhos(x, y, coords);


                if (coords[1][0]!=33){
                    return false;
                }
            }
        }

        return true;
    }


    public int pontos(){
        int valor = 0;
        for (int i=0; i<tab.length; i++){
            for (int j=0; j<tab.length; j++){
                if (tab[i][j]!=0){
                    valor++;
                    Math.pow(valor,valor);
                }
            }
        }
        return valor;
    }


}


